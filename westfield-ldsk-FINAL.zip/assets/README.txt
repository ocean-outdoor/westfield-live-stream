Place your branded frame image here as:

branding.png

Requirements:
- Size: 640px x 1280px (or your screen dimensions)
- Format: PNG with transparency (recommended) or JPG
- Design: Create frame with transparent areas where video should show through

The frame will overlay on top of the fullscreen video.
